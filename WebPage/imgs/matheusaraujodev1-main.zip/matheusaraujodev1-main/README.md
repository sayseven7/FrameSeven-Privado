
<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=0bfeee&height=120&section=header"/>

[![Typing SVG](https://readme-typing-svg.herokuapp.com/?color=00BFFF&size=35&center=true&vCenter=true&width=1000&lines=HELLO,+My+name+is+Matheus+Araujo+😉+👋🏿;I'm+a+Full-stack+developer+jr+💻+👨🏿‍💻;I'm+21+years+old;I'm+from+Brazil;I+Be+Welcome!+😎)](https://git.io/typing-svg)

<div align="center">  
  <img width="49%" height="195px" src="https://github-readme-stats.vercel.app/api?username=matheusaraujodev1&show_icons=true&count_private=true&hide_border=true&title_color=0bfeee&icon_color=0bfeee&text_color=c9d1d9&bg_color=0d1117" alt="Matheus Araujo github stats" /> 
  <img width="41%" height="195px" src="https://github-readme-stats.vercel.app/api/top-langs/?username=matheusaraujodev1&layout=compact&hide_border=true&title_color=0bfeee&text_color=c9d1d9&bg_color=0d1117" />
</div>

---

[![Ashutosh's github activity graph](https://github-readme-activity-graph.cyclic.app/graph?username=matheusaraujodev1&bg_color=0d1117&color=0bfeee&line=34a1bc&point=00bfff&area=true&hide_border=true)](https://github.com/ashutosh00710/github-readme-activity-graph)



---




<div align="center" > 
<P>CONTACT:</P>
<a href = "mailto:matheusaraujodev1@gmail.com"  target="_blank"> <img src="https://img.shields.io/badge/-Gmail-%23333?style=for-the-badge&logo=gmail&logoColor=white" target="_blank"></a>
<a href="https://github.com/matheusaraujodev1" target="_blank"> <img src="https://img.shields.io/badge/GitHub-100000?style=for-the-badge&logo=github&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
<a href="https://www.linkedin.com/in/matheus-araujodev-317326248/" target="_blank"><img src="https://img.shields.io/badge/-LinkedIn-%230077B5?style=for-the-badge&logo=linkedin&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
<a href="https://wa.me/5571988571202" target="_blank"><img src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" style="border-radius: 30px" target="_blank"></a> 

 </div>
 
<br> 
 

 <div align="center">
<P>STUDYING IN THIS MOMENT: </P>
<a> <img src="https://img.shields.io/badge/React-20232A?style=for-the-badge&logo=react&logoColor=61DAFB" target="_blank"></a>
<a> <img src="https://img.shields.io/badge/TypeScript-007ACC?style=for-the-badge&logo=typescript&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
<a ><img src="https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
<a ><img src="https://img.shields.io/badge/Bootstrap-563D7C?style=for-the-badge&logo=bootstrap&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
<a ><img src="https://img.shields.io/badge/MongoDB-4EA94B?style=for-the-badge&logo=mongodb&logoColor=white" style="border-radius: 30px" target="_blank"></a> 

</div>

<br>


 <div align="center">
<P>MY SKILLS:</P>
<a> <img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" target="_blank"></a>
<a> <img src="https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
<a ><img src="https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
<a ><img src="https://img.shields.io/badge/Git-E34F26?style=for-the-badge&logo=git&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
<a ><img src="https://img.shields.io/badge/Linux-E34F26?style=for-the-badge&logo=linux&logoColor=black" style="border-radius: 30px" target="_blank"></a> 
<a ><img src="https://img.shields.io/badge/Windows-017AD7?style=for-the-badge&logo=windows&logoColor=white" style="border-radius: 30px" target="_blank"></a> 
</div>


<div align="center">
<br><p align="centre"><b>Visitors Count</b></p>  
<p align="center"><img align="center" src="https://profile-counter.glitch.me/{matheusaraujodev1}/count.svg" /></p> 
<br>
</div>


<img width=100% src="https://capsule-render.vercel.app/api?type=waving&color=0bfeee&height=120&section=footer"/>

