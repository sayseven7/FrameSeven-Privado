const button = document.querySelector('.download-frameseven');

button.addEventListener('click', e => {
    e.preventDefault();

    console.log('clicado')
})